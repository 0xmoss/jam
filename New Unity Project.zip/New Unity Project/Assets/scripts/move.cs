﻿using UnityEngine;
using System.Collections;
public class move : MonoBehaviour
{

    public float speed = 0.05f;
    public float jumph = 4.01f;
    public float inerci = 0.002f;
    public float moov = 0;

    void Start() { print("Start"); }

    void Update()
    {
        Vector3 dp = new Vector3();

        if (Input.GetKey(KeyCode.Q) && moov > -speed)
        {
            moov -= inerci;
        }
        else if (moov < 0)
        {
            moov += inerci;
        }

        if (Input.GetKey(KeyCode.D) && moov < speed)
        {
            moov += inerci;
        }
        else if (moov > 0)
        {
            moov -= inerci;
        }
        dp.x += moov;

/*        if (Input.GetKey(KeyCode.spacebar))
        {
            dp.y += 1;
        }*/

        transform.position += dp;
    }
}